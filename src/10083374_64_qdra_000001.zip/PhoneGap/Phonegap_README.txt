READ ME - LeadBolt Android Cordova Phonegap library

Version 1.0      date: 2013-11-07
================================================================================================================== 

Scope
--------
This zip package provides a wrapping library to allow Phonegap users on Android to include the LeadBolt SDK within their Applications.

Requirements
------------

1. You must have a LeadBolt app publisher account (http://www.leadbolt.com)

2. You must have accessed your leadbolt account to register your android app and have created ads, retrieved the relevant section ids.

3. From the help/faq section of the leadbolt portal, you must have downloaded the latest (version 6.3 and above) LeadBolt android publisher SDK.


Integration
------------
The following steps need to be followed in the ADT IDE or Eclipse

1. Unzip and copy the LeadBolt Android SDK into the "libs" folder of your project. This should be the <yoursdkpackagename>.jar file

2. Copy the LeadBolt Android Phonegap Plugin into the "libs" folder of your project. This should be the LeadBoltPhonegap.jar file found in the downloaded SDK zip file.

3. Copy the AppFireworks.jar (found in the AppFireworks folder) and AppFireworksPhonegap.jar (found in Phonegap/AppFireworks folder) into the "libs" folder.

3. Edit the config.xml (found in res/xml folder of your Android Project). Add the following lines along with the other features already defined there:
	<feature name="AdController">
		<param name="android-package" value="com.leadbolt.phonegap.android.LBPhonegapPlugin" />
	</feature>
	<feature name="AppTracker">
		<param name="android-package" value="com.appfireworks.android.phonegap.AppTrackerPlugin" />
	</feature>

4. In the config.xml file, please make sure <access> tag is set to the following, otherwise the SDK may not be able to track events properly:
	<access origin="*" />

5. In your App's AndroidManifest.xml file add the following permissions:
    
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>


6. Copy AdController.js and AppTracker.js (found in the PhoneGap/AppFireworks folder) files into the assets/js folder of your App and add the following script tag in your HTML code:
    <script type="text/javascript" src="js/AdController.js"></script>
    <script type="text/javascript" src="js/AppTracker.js"></script>

7. Now in your index.html file add the following lines:

	document.addEventListener('deviceready', function() {
		loadLeadbolt();
	}, false);

	function loadLeadbolt()
	{
		// Initialize ad serving + AppFireworks
		AdController.loadAd("YOUR_LB_AUDIO_ID");
		AppTracker.startSession("APPFIREWORKS_API_KEY"); // analytics only
		loadDisplayAd();
	}

    function loadDisplayAd() {
    	// Use this function elsewhere in your App to display a Leadbolt interstitial Ad
        AdController.loadAd("YOUR_LB_INTERSTITIAL_ID");
    }


Going Live 
-----------
Once your app is working you can now go-live with real ads.

1. Access the LeadBolt publisher portal and for your app click the go-live button if present.

2. Your app will be submited for approval and once approved will receive live ads.