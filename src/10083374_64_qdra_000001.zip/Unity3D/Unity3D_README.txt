READ ME - Leadbolt Unity3D library

Version 2.2      updated: 2014-07-24
================================================================================================================== 

Scope
--------
This zip package provides a wrapping library to allow Unity3D users to include the LeadBolt publisher sdk within their Unity3D applications.

Requirements
------------

1. You must have an Unity3D account that allows inclusion of 3rd party Plugins

2. You must have a LeadBolt app publisher account (http://www.leadbolt.com)

3. You must have accessed your leadbolt account to register your android app and have created ads, retrieved the relevant section ids.

4. From the help/faq section of the leadbolt portal, you must have downloaded the latest (version 6.3 and above) LeadBolt android publisher SDK.


Integration
------------
The following needs to be completed before opening the Unity3D IDE

1. In your Unity3D workspace folder, first check if the "Assets->Plugins->Android" folders exist. If they dont then please create this path first.

2. Copy the LeadBolyUnity.jar provided in the downloaded SDK zip file to the "Assets->Plugins->Android" folder of your Project.

3. Copy the LeadBolt SDK jar file into the "Assets->Plugins->Android" folder.

4. Copy AppFireworks.jar file (found in the AppFireworks folder with the downloaded SDK zip file) into the "Assets->Plugins->Android" folder.


The following needs to be completed in the Unity3D IDE

1. Open the Unity3D IDE and click on "Assets->Import New Package->Custom Package" and select appfireworks_android_unity.unitypackage.

2. Add the relevant C# code for displaying/loading LeadBolt Ads. In your C# code where you want the LeadBolt Ad to display, add the following code:

void Start()
{
	// Initialize Ad serving + AppFireworks
	AdController.initAdWithSectionId ("YOUR_LB_AUDIO_ID",AdController.TYPE_AUDIO);
	AdController.loadAudioAd();

	AppTrackerAndroid.onModuleFailedEvent += onModuleFailedEvent;	
	AppTrackerAndroid.startSession("APPFIREWORKS_API_KEY");
}

void onModuleFailedEvent()
{
	loadDisplayAd();
}

void loadDisplayAd()
{
	// Use this function elsewhere in your App to display a Leadbolt interstitial Ad
	AdController.initAdWithSectionId ("YOUR_LB_INTERSTITIAL_ID",AdController.TYPE_DISPLAY);
	// AdController.loadAdToCache(); // Un-comment and place appropriately to cache Ad
	AdController.loadAd();
}


3. Need to add permissions in your AndroidManifest.xml file. For your Android Project, you will have a AndroidManifest.xml file in your "Assets->Plugins->Android" folder. In there add the following permissions

	<uses-permission android:name="android.permission.INTERNET"/>
	<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>

4. In the AndroidManifest.xml file, inside the <activity android:name="com.unity3d.player.UnityPlayerProxyActivity" ....> tab, add the following line:
	<meta-data android:name="unityplayer.ForwardNativeEventsToDalvik" android:value="true" /> 

	Please note: This line must be put just before the </activity>

5. Build and Run your application from the Unity3D IDE to check you see LeadBolt ads.

Going Live 
-----------
Once your app is working you can now go-live with real ads.

1. Access the LeadBolt publisher portal and for your app click the go-live button if present.

2. Your app will be submited for approval and once approved will receive live ads.