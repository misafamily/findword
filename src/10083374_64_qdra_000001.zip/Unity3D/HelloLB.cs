using UnityEngine;
using System.Collections;

public class HelloLB : MonoBehaviour {
	private float xCentre = Screen.width /2;
	private float yCentre = Screen.height / 2;
	
	
	void Start () {
		Screen.orientation = ScreenOrientation.AutoRotation; //to allow orientation other than portrait
		
		AppTrackerAndroid.onModuleFailedEvent += onModuleFailedEvent;
		
		AppTrackerAndroid.startSession("is2byYEVjbXiFjVjaYIt6sM4aEIqMWZ3"); // Please change this demo API Key to your own API Key 
	}
	
	void OnGUI ()
	{
		
		GUI.Label (new Rect (xCentre - 100, yCentre - 120, 300, 100), "Wait a few seconds for Ad to load");
		GUI.Label (new Rect (xCentre - 10, yCentre - 80, 50, 100), "OR");
		
		if (GUI.Button (new Rect (xCentre - 130, yCentre -40, 260, 100), "Click here to show Ad")) {
			AppTrackerAndroid.loadModule("inapp");
		}
		
	}
	
	void Update () {
		if (Input.GetKey(KeyCode.Escape))
			Application.Quit();
	}
	
	void onModuleFailedEvent() {
		Debug.Log ("ModuleFailed - going to load Leadbolt");
		AdController.initAdWithSectionId ("249946078",AdController.TYPE_DISPLAY);
		AdController.loadAd();
	}
}
