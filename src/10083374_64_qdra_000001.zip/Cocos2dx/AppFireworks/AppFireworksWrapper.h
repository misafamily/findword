//
//  AppFireworkWrapper.h
//  HelloCpp
//
//  Created by Tech on 1/10/13.
//
//

#ifndef __AppFireworksWrapper__
#define __AppFireworksWrapper__

#include "cocos2d.h"

class AppFireworksWrapper
{
public:
    static void startSession(const char* apiKey);
    static void loadModule(const char* placement);
    static void loadModuleToCache(const char* placement);
    static void destroyModule();
	
    static void event(const char* name);
    static void event(const char* name, float floatValue);

    static void transaction(const char* name, float floatValue, const char* currencyCode);
    
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    static void closeSession(bool sync);
    static void pause();
    static void resume();
#else
    static void closeSession();
#endif    

};

#endif /* defined(__AppFireworkWrapper__) */
