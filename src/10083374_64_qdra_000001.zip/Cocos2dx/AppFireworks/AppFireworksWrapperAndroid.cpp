
#include "AppFireworksWrapper.h"
#include "platform/android/jni/JniHelper.h"

#include <jni.h>
#include <string.h>
#include <android/log.h>

USING_NS_CC;

#define  CLASS_NAME "com/appfireworks/cocos2dx/android/AppFireworksWrapper"


static void callStaticFunction(const char* funcName)
{
    cocos2d::JniMethodInfo methodinfo;
    if (cocos2d::JniHelper::getStaticMethodInfo(methodinfo, CLASS_NAME, funcName, "()V")) {
        
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID);
    }
}

void AppFireworksWrapper::resume()
{
    callStaticFunction("resume");
}

void AppFireworksWrapper::pause()
{
    callStaticFunction("pause");
}

void AppFireworksWrapper::startSession(const char* apiKey)
{
    cocos2d::JniMethodInfo methodinfo;
    if (cocos2d::JniHelper::getStaticMethodInfo(methodinfo, CLASS_NAME, "startSession", "(Ljava/lang/String;)V"))
    {
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID, methodinfo.env->NewStringUTF(apiKey));
    }  
}

void AppFireworksWrapper::closeSession(bool sync)
{
    cocos2d::JniMethodInfo methodinfo;
    if (cocos2d::JniHelper::getStaticMethodInfo(methodinfo, CLASS_NAME, "closeSession", "(Z)V"))
    {
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID, sync);
    }
}

void AppFireworksWrapper::event(const char* name)
{
    cocos2d::JniMethodInfo methodinfo;
    if (cocos2d::JniHelper::getStaticMethodInfo(methodinfo, CLASS_NAME, "event", "(Ljava/lang/String;)V"))
    {
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID, methodinfo.env->NewStringUTF(name));
    }
}

void AppFireworksWrapper::event(const char* name, float value)
{
    cocos2d::JniMethodInfo methodinfo;
    if (cocos2d::JniHelper::getStaticMethodInfo(methodinfo, CLASS_NAME, "event", "(Ljava/lang/String;F)V"))
    {
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID, methodinfo.env->NewStringUTF(name), value);
    }
}

void AppFireworksWrapper::loadModule(const char* placement)
{
    cocos2d::JniMethodInfo methodinfo;
    if (cocos2d::JniHelper::getStaticMethodInfo(methodinfo, CLASS_NAME, "loadModule", "(Ljava/lang/String;)V"))
    {
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID, methodinfo.env->NewStringUTF(placement));
    }  
}

void AppFireworksWrapper::loadModuleToCache(const char* placement)
{
    cocos2d::JniMethodInfo methodinfo;
    if (cocos2d::JniHelper::getStaticMethodInfo(methodinfo, CLASS_NAME, "loadModuleToCache", "(Ljava/lang/String;)V"))
    {
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID, methodinfo.env->NewStringUTF(placement));
    }  
}

void AppFireworksWrapper::destroyModule()
{
    callStaticFunction("destroyModule");
}

void AppFireworksWrapper::transaction(const char* name, float floatValue, const char* currencyCode)
{
    const char *paramCode = "(Ljava/lang/String;FLjava/lang/String;)V";
    
    cocos2d::JniMethodInfo methodinfo;
    if (cocos2d::JniHelper::getStaticMethodInfo(methodinfo, CLASS_NAME, "transaction", paramCode))
    {
        jstring jstrName = methodinfo.env->NewStringUTF(name);
        jstring jstrCurrencyCode = methodinfo.env->NewStringUTF(currencyCode);
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID, jstrName, floatValue, jstrCurrencyCode);
    }
}

