
#include "LeadboltAdWrapper.h"
#include "platform/android/jni/JniHelper.h"

#include <jni.h>
#include <string.h>
#include <android/log.h>

USING_NS_CC;

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)


#define  JAVA_CLASS_NAME "com/leadbolt/cocos2dx/android/LeadboltAdWrapper"

void LeadboltAdWrapper::loadStartAd(const char* lbAppAdId, const char* lbAudioId, const char* lbReEngamentId)
{
    cocos2d::JniMethodInfo methodinfo;

    if (cocos2d::JniHelper::getStaticMethodInfo(methodinfo, JAVA_CLASS_NAME, "loadStartAd",
                                                "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V"))
    {
        jstring jstrAppAdId = methodinfo.env->NewStringUTF(lbAppAdId);
        jstring jstrAudioId = methodinfo.env->NewStringUTF(lbAudioId);
        jstring jstrReEngamentId = methodinfo.env->NewStringUTF(lbReEngamentId);
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID, jstrAppAdId, jstrAudioId, jstrReEngamentId);
    }
}

void LeadboltAdWrapper::loadAd(const char* lbAppAdId)
{
    cocos2d::JniMethodInfo methodinfo;
    if(cocos2d::JniHelper::getStaticMethodInfo(methodinfo, JAVA_CLASS_NAME, "loadAd", "(Ljava/lang/String;)V"))
    {
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID, methodinfo.env->NewStringUTF(lbAppAdId));
    }
}

void LeadboltAdWrapper::loadAdToCache(const char* lbAppAdId)
{
    cocos2d::JniMethodInfo methodinfo;
    if(cocos2d::JniHelper::getStaticMethodInfo(methodinfo, JAVA_CLASS_NAME, "loadAdToCache", "(Ljava/lang/String;)V"))
    {
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID, methodinfo.env->NewStringUTF(lbAppAdId));
    }
}

void LeadboltAdWrapper::loadAudioAd(const char* lbAudioId)
{
    cocos2d::JniMethodInfo methodinfo;
    if(cocos2d::JniHelper::getStaticMethodInfo(methodinfo, JAVA_CLASS_NAME, "loadAudioAd", "(Ljava/lang/String;)V"))
    {
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID, methodinfo.env->NewStringUTF(lbAudioId));
    }
}

void LeadboltAdWrapper::loadReEngagement(const char* lbReEngamentId)
{
    cocos2d::JniMethodInfo methodinfo;
    if(cocos2d::JniHelper::getStaticMethodInfo(methodinfo, JAVA_CLASS_NAME, "loadReEngagement", "(Ljava/lang/String;)V"))
    {
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID, methodinfo.env->NewStringUTF(lbReEngamentId));
    }
}

void LeadboltAdWrapper::loadAudioTrack(const char* lbAudioId, int audioTrack)
{
    cocos2d::JniMethodInfo methodinfo;
    if(cocos2d::JniHelper::getStaticMethodInfo(methodinfo, JAVA_CLASS_NAME, "loadAudioTrack", "(Ljava/lang/String;I)V"))
    {
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID, methodinfo.env->NewStringUTF(lbAudioId), audioTrack);
    }
}

static void callStaticFunctionNoPara(const char* funcName)
{
    cocos2d::JniMethodInfo methodinfo;
    if (cocos2d::JniHelper::getStaticMethodInfo(methodinfo, JAVA_CLASS_NAME, funcName, "()V"))
    {
        methodinfo.env->CallVoidMethod(methodinfo.classID, methodinfo.methodID);
    }
}

void LeadboltAdWrapper::destroyAd()
{
    callStaticFunctionNoPara("destroyAd");
}

#endif

