READ ME - LeadBolt Basic4Android library

Version 2.0      date: 2013-11-107
================================================================================================================== 

Scope
--------
This zip package provides a wrapping library to allow basic4android users to include the leadbolt publisher sdk within their basic4android applications.

Requirements
------------

1. You must have a basic4android account that allows inclusion of 3rd party libraries (http://www.basic4ppc.com)

2. You must have a LeadBolt app publisher account (http://www.leadbolt.com)

3. You must have accessed your leadbolt account to register your android app and have created ads, retrieved the relevant section ids.

4. From the help/faq section of the leadbolt portal, you must have downloaded the latest (version 6.3 and above) LeadBolt android publisher SDK.


Integration
------------
The following needs to be completed in the basic4android IDE


1. Copy the LeadBoltB4A.jar, LeadBoltB4A.xml, Leadbolt SDK xml file, Leadbolt SDK jar file, AppFireworksB4A.jar, AppFireworksB4A.xml, AppFireworks.xml and AppFireworks.jar (found in the AppFireworks folder) into your B4A libs folder

2. In the Basic4Android IDE, add references to your LeadBolt SDK jar, LeadBoltB4A.jar, AppFireworks.jar and AppFireworksB4A.jar in your project.

3. Add the relevant code to display LeadBolt ads within your app. Following is the typical code for adding ads to your Basic4Android project:


'Activity module
Sub Globals
	Dim ad As LeadboltB4A
	Dim AppTracker as AppFireworksB4A
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("Main")

	' Initialize Ad serving + AppFireworks
	ad.Initialize("YOUR_LB_AUDIO_ID")
	ad.loadAudioAd()

	AppTracker.Initialize("APPFIREWORKS_API_KEY")
	AppTracker.startSession()
End Sub

Sub appfireworks_onmodulefailed()
	LoadLeadbolt()
End Sub

Sub LoadLeadbolt()
	'Use this function elsewhere in your App to display a Leadbolt interstitial Ad
	ad.Initialize("YOUR_LB_INTERSTITIAL_ID")
	' ad.loadAdToCache() 'Un-comment and place appropriately to cache Ad
	ad.loadAd()
End Sub
 

4. Open Manifest Editor in B4A by clicking "Project->Manifest Editor".

5. In the AddManifestTest block add the following permissions:
	<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
	<uses-permission android:name="android.permission.INTERNET"/>
	
6. Run your application in the Basic4Android emulator to check you see LeadBolt test ads.


Going Live 
-----------
Once your app is working you can now go-live with real ads.

1. Access the LeadBolt publisher portal and for your app click the go-live button if present.

2. Your app will be submited for approval and once approved will receive live ads.